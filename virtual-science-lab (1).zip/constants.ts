
import { Board, ClassLevel, Subject } from './types';

export const BOARDS: Board[] = ['CBSE', 'ICSE', 'State Board'];
export const CLASSES: ClassLevel[] = ['9th', '10th', '11th', '12th'];
export const SUBJECTS: Subject[] = ['Physics', 'Chemistry', 'Biology'];

export const EXPERIMENTS_DATA: Record<Subject, { chapter: string, experiments: string[] }[]> = {
  Physics: [
    { chapter: 'Mechanics', experiments: ["Verification of Ohm's Law", "Simple Pendulum Experiment", "Fluid Pressure and Flow"] },
    { chapter: 'Optics', experiments: ['Focal Length of a Concave Mirror', 'Refractive Index of a Glass Slab'] },
    { chapter: 'Electricity', experiments: ['Resistors in Series and Parallel', 'To study the characteristics of a Zener diode'] }
  ],
  Chemistry: [
    { chapter: 'Solutions & Titrations', experiments: ['Titration of HCl with NaOH', 'Preparation of a Standard Solution of Oxalic Acid'] },
    { chapter: 'Qualitative Analysis', experiments: ['Salt Analysis: Identify Cation and Anion', 'Test for Functional Groups in Organic Compounds'] },
    { chapter: 'Chemical Kinetics', experiments: ['Effect of Concentration on Reaction Rate', 'Study of the reaction rate of reaction between Sodium Thiosulphate and Hydrochloric Acid'] }
  ],
  Biology: [
    { chapter: 'Microscopy', experiments: ['Prepare a Temporary Mount of an Onion Peel', 'Observing Stomata in a Leaf Peel'] },
    { chapter: 'Physiology', experiments: ['Study of Osmosis by Potato Osmoscope', 'Demonstrate that CO2 is released during Respiration'] },
    { chapter: 'Genetics', experiments: ['Study of Mitosis in Onion Root Tip Cells', 'Human Blood Group Testing'] }
  ]
};