
import React, { useState, useCallback } from 'react';
import Onboarding from './components/Onboarding';
import Dashboard from './components/Dashboard';
import ExperimentView from './components/ExperimentView';
import { OnboardingData, Subject } from './types';
import { HeaderIcon } from './components/icons';

type View = 'onboarding' | 'dashboard' | 'experiment';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>('onboarding');
  const [onboardingData, setOnboardingData] = useState<OnboardingData | null>(null);
  const [selectedExperiment, setSelectedExperiment] = useState<string | null>(null);

  const handleOnboardingComplete = useCallback((data: OnboardingData) => {
    setOnboardingData(data);
    setCurrentView('dashboard');
  }, []);

  const handleSelectExperiment = useCallback((experimentName: string) => {
    setSelectedExperiment(experimentName);
    setCurrentView('experiment');
  }, []);
  
  const handleBackToDashboard = useCallback(() => {
    setSelectedExperiment(null);
    setCurrentView('dashboard');
  }, []);

  const handleBackToOnboarding = useCallback(() => {
    setOnboardingData(null);
    setSelectedExperiment(null);
    setCurrentView('onboarding');
  }, []);

  const renderContent = () => {
    switch (currentView) {
      case 'onboarding':
        return <Onboarding onComplete={handleOnboardingComplete} />;
      case 'dashboard':
        if (onboardingData) {
            return <Dashboard 
                subject={onboardingData.subject} 
                onSelectExperiment={handleSelectExperiment} 
                onBack={handleBackToOnboarding}
            />;
        }
        return null;
      case 'experiment':
        if (onboardingData && selectedExperiment) {
            return <ExperimentView 
                experimentName={selectedExperiment} 
                subject={onboardingData.subject}
                onBack={handleBackToDashboard}
            />;
        }
        return null;
      default:
        return <Onboarding onComplete={handleOnboardingComplete} />;
    }
  };

  return (
    <div className="bg-slate-900 text-white min-h-screen">
      <header className="bg-slate-900/80 backdrop-blur-sm border-b border-slate-700 sticky top-0 z-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <HeaderIcon />
            <h1 className="text-2xl font-bold text-cyan-400">Virtual Science Lab</h1>
          </div>
        </div>
      </header>
      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderContent()}
      </main>
    </div>
  );
};

export default App;
