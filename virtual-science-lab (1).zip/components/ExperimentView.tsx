import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Subject, ExperimentDetails, ExperimentResult, ProcedureStep } from '../types';
import { generateExperimentDetails, generateExperimentResults, generateExperimentVideo } from '../services/geminiService';
import { BackIcon, InfoIcon, ScienceIcon, ResultsIcon, WarningIcon, BeakerIcon, FlaskIcon, PipetteIcon, BurnerIcon, CheckIcon as StepCheckIcon, TripodStandIcon, WaterMoleculeIcon, HClMoleculeIcon, NaOHMoleculeIcon, PhIcon, TemperatureIcon, ConcentrationIcon, EarthIcon, MarsIcon, MoonIcon, RocketIcon, PlusIcon, SpeedIcon, PressureIcon, SaveIcon, LoadIcon, RefreshIcon, VideoIcon, KeyIcon, DownloadIcon, FlameIcon } from './icons';
import Spinner from './Spinner';
import ResultsCharts from './ResultsCharts';

interface ExperimentViewProps {
  experimentName: string;
  subject: Subject;
  onBack: () => void;
}

type GravityOption = 'Zero-G' | 'Moon' | 'Mars' | 'Earth';

interface SavedState {
  experimentName: string;
  currentStep: number;
  usedApparatus: string[];
  results: ExperimentResult | null;
  gravity: GravityOption;
  reactionSpeed: number;
  pressure: number;
  ambientTemperature: number;
  flameIntensity: number;
  mixture: Record<string, { name: string; amount: number; type: string }>;
}

const GRAVITY_MAP: Record<GravityOption, number> = {
    'Zero-G': 0,
    'Moon': 1.62,
    'Mars': 3.72,
    'Earth': 9.81,
};

const VIDEO_LOADING_MESSAGES = [
    "Initializing quantum video synthesizer...",
    "Calibrating the chroniton emitters...",
    "Rendering molecular animations...",
    "Polishing the final frames...",
    "Almost there! Your video is being prepared.",
];

const GravityControl: React.FC<{ selected: GravityOption; onSelect: (g: GravityOption) => void }> = ({ selected, onSelect }) => {
    const options: { name: GravityOption, icon: React.ReactNode }[] = [
        { name: 'Zero-G', icon: <RocketIcon /> },
        { name: 'Moon', icon: <MoonIcon /> },
        { name: 'Mars', icon: <MarsIcon /> },
        { name: 'Earth', icon: <EarthIcon /> },
    ];

    return (
        <div className="bg-slate-900/50 p-3 rounded-lg border border-slate-700">
            <h4 className="text-md font-semibold text-cyan-400 mb-3 text-center">Gravity Control</h4>
            <div className="flex justify-around items-center gap-2">
                {options.map(({ name, icon }) => (
                    <button
                        key={name}
                        onClick={() => onSelect(name)}
                        title={`${name} (${GRAVITY_MAP[name]} m/s²)`}
                        className={`flex flex-col items-center gap-1 p-2 rounded-md transition-all w-16 ${
                            selected === name ? 'bg-cyan-500/20 text-cyan-300' : 'text-slate-400 hover:bg-slate-700'
                        }`}
                    >
                        {icon}
                        <span className="text-xs font-medium">{name}</span>
                    </button>
                ))}
            </div>
        </div>
    );
};

const SimulationControls: React.FC<{
    subject: Subject;
    experimentName: string;
    procedureSteps: ProcedureStep[];
    reactionSpeed: number;
    onReactionSpeedChange: (value: number) => void;
    pressure: number;
    onPressureChange: (value: number) => void;
    ambientTemperature: number;
    onAmbientTemperatureChange: (value: number) => void;
    flameIntensity: number;
    onFlameIntensityChange: (value: number) => void;
}> = ({
    subject,
    experimentName,
    procedureSteps,
    reactionSpeed, onReactionSpeedChange,
    pressure, onPressureChange,
    ambientTemperature, onAmbientTemperatureChange,
    flameIntensity, onFlameIntensityChange,
}) => {
    const isTitration = subject === 'Chemistry' && experimentName.toLowerCase().includes('titration');
    const isFluidExperiment = subject === 'Physics' && experimentName.toLowerCase().includes('fluid');
    const hasHeatStep = useMemo(() => {
        if (!procedureSteps) return false;
        return procedureSteps.some(step => step.key === 'HEAT');
    }, [procedureSteps]);

    if (!isTitration && !isFluidExperiment && !(subject === 'Chemistry' && hasHeatStep)) {
        return null;
    }

    return (
        <div className="bg-slate-900/50 p-4 rounded-lg border border-slate-700 space-y-4">
            <h4 className="text-md font-semibold text-cyan-400 text-center">Environmental Controls</h4>
            
            {subject === 'Chemistry' && hasHeatStep && (
                 <div className="relative group">
                    <div className="flex justify-between items-center text-sm mb-1">
                        <label htmlFor="flameIntensity" className="flex items-center gap-2 text-slate-300">
                            <FlameIcon size="sm" /> Flame Intensity
                        </label>
                        <span className="font-mono text-cyan-300">{flameIntensity.toFixed(1)}x</span>
                    </div>
                    <input
                        type="range" id="flameIntensity" min="0.5" max="2" step="0.1" value={flameIntensity}
                        onChange={(e) => onFlameIntensityChange(parseFloat(e.target.value))}
                        className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-orange-500"
                    />
                     <div className="absolute bottom-6 left-1/2 -translate-x-1/2 w-max px-2 py-1 bg-slate-900 text-slate-200 text-xs rounded-md shadow-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
                        Adjusts heating speed and temperature changes.
                    </div>
                </div>
            )}

            {isTitration && (
                <>
                    <div className="relative group">
                        <div className="flex justify-between items-center text-sm mb-1">
                            <label htmlFor="reactionSpeed" className="flex items-center gap-2 text-slate-300">
                                <SpeedIcon size="sm" /> Reaction Speed
                            </label>
                            <span className="font-mono text-cyan-300">{reactionSpeed.toFixed(1)}x</span>
                        </div>
                        <input
                            type="range" id="reactionSpeed" min="0.5" max="4" step="0.1" value={reactionSpeed}
                            onChange={(e) => onReactionSpeedChange(parseFloat(e.target.value))}
                            className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-500"
                        />
                         <div className="absolute bottom-6 left-1/2 -translate-x-1/2 w-max px-2 py-1 bg-slate-900 text-slate-200 text-xs rounded-md shadow-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
                            Controls the reaction rate and affects monitoring graphs.
                        </div>
                    </div>
                    <div className="relative group">
                        <div className="flex justify-between items-center text-sm mb-1">
                            <label htmlFor="ambientTemperature" className="flex items-center gap-2 text-slate-300">
                                <TemperatureIcon size="sm" /> Ambient Temp.
                            </label>
                            <span className="font-mono text-cyan-300">{ambientTemperature.toFixed(0)}°C</span>
                        </div>
                        <input
                            type="range" id="ambientTemperature" min="0" max="50" step="1" value={ambientTemperature}
                            onChange={(e) => onAmbientTemperatureChange(parseInt(e.target.value, 10))}
                             className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-500"
                        />
                        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 w-max px-2 py-1 bg-slate-900 text-slate-200 text-xs rounded-md shadow-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
                            Sets the starting temperature for the experiment.
                        </div>
                    </div>
                </>
            )}

            {isFluidExperiment && (
                <div className="relative group">
                    <div className="flex justify-between items-center text-sm mb-1">
                        <label htmlFor="pressure" className="flex items-center gap-2 text-slate-300">
                            <PressureIcon size="sm" /> Pressure
                        </label>
                        <span className="font-mono text-cyan-300">{pressure.toFixed(1)} atm</span>
                    </div>
                    <input
                        type="range" id="pressure" min="0.5" max="3" step="0.1" value={pressure}
                        onChange={(e) => onPressureChange(parseFloat(e.target.value))}
                         className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-500"
                    />
                    <div className="absolute bottom-6 left-1/2 -translate-x-1/2 w-max px-2 py-1 bg-slate-900 text-slate-200 text-xs rounded-md shadow-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
                        Influences the flow rate between chambers.
                    </div>
                </div>
            )}
        </div>
    );
};


const ApparatusIcon = ({ name }: { name: string }) => {
    const lowerName = name.toLowerCase();
    if (lowerName.includes('beaker')) return <BeakerIcon />;
    if (lowerName.includes('flask') || lowerName.includes('osmoscope')) return <FlaskIcon />;
    if (lowerName.includes('pipette') || lowerName.includes('dropper') || lowerName.includes('burette')) return <PipetteIcon />;
    if (lowerName.includes('burner') || lowerName.includes('lamp') || lowerName.includes('heater')) return <BurnerIcon />;
    if (lowerName.includes('stand') || lowerName.includes('tripod') || lowerName.includes('pendulum')) return <TripodStandIcon />;
    return <ScienceIcon />;
};

const ApparatusItem: React.FC<{ name: string; onClick: () => void; isUsed: boolean; isHighlighted: boolean; isSetupPhase: boolean; }> = ({ name, onClick, isUsed, isHighlighted, isSetupPhase }) => (
    <button
        onClick={onClick}
        disabled={isUsed || !isSetupPhase}
        className={`relative p-3 w-24 h-24 flex flex-col items-center justify-center gap-2 text-center bg-slate-700/50 rounded-lg border-2 transition-all duration-300 ${
            isUsed 
                ? 'border-green-500 opacity-50' 
                : isHighlighted
                ? 'border-cyan-400 scale-105 shadow-lg shadow-cyan-500/20 animate-pulse'
                : `border-slate-600 ${isSetupPhase ? 'hover:border-cyan-400 hover:bg-slate-700' : 'cursor-default'}`
        }`}
    >
        <ApparatusIcon name={name} />
        <span className="text-xs text-slate-300">{name}</span>
        {isUsed && (
            <div className="absolute top-1 right-1 bg-green-500 rounded-full p-0.5 text-white">
                <StepCheckIcon />
            </div>
        )}
    </button>
);

const BubbleParticles: React.FC<{ count: number; intensity: 'low' | 'high' }> = ({ count, intensity }) => {
    const bubbles = useMemo(() => Array.from({ length: count }).map((_, i) => {
        const style = {
            left: `${Math.random() * 80 + 10}%`,
            animationDuration: `${Math.random() * (intensity === 'high' ? 1.5 : 3) + 1}s`,
            animationDelay: `${Math.random() * 2}s`,
        };
        const size = intensity === 'high' ? 'w-1.5 h-1.5' : 'w-1 h-1';
        return <div key={i} className={`absolute bottom-0 ${size} bg-cyan-400/50 rounded-full animate-bubble`} style={style}></div>;
    }), [count, intensity]);

    return <div className="absolute inset-0 pointer-events-none">{bubbles}</div>;
};


const LabStage: React.FC<{ 
    stepKey: string;
    experimentName: string;
    subject: Subject;
    gravity: GravityOption;
    pressure: number;
    flameIntensity: number;
    usedApparatus: string[];
}> = ({ stepKey, experimentName, subject, gravity, pressure, flameIntensity, usedApparatus }) => {
    const isTitration = subject === 'Chemistry' && experimentName.toLowerCase().includes('titration');
    const isPendulum = subject === 'Physics' && experimentName.toLowerCase().includes('pendulum');
    const isFluidExperiment = subject === 'Physics' && experimentName.toLowerCase().includes('fluid');

    const animationKeyframes = `
        @keyframes pop-in {
            0% { transform: scale(0.5) translateY(20px); opacity: 0; }
            100% { transform: scale(1) translateY(0); opacity: 1; }
        }
        @keyframes swing-damped {
            0%   { transform: rotate(40deg); }
            12.5% { transform: rotate(-32deg); }
            25%  { transform: rotate(24deg); }
            37.5% { transform: rotate(-16deg); }
            50%  { transform: rotate(8deg); }
            62.5% { transform: rotate(-4deg); }
            75%  { transform: rotate(2deg); }
            87.5% { transform: rotate(-1deg); }
            100% { transform: rotate(0deg); }
        }
        @keyframes bubble {
            0% { transform: translateY(0) scale(0.5); opacity: 0.7; }
            100% { transform: translateY(-80px) scale(1); opacity: 0; }
        }
    `;

    const gravityValue = GRAVITY_MAP[gravity];
    const pendulumPeriodFactor = gravityValue > 0 ? 1 / Math.sqrt(gravityValue / GRAVITY_MAP['Earth']) : 0;
    const fluidFlowDuration = (gravityValue > 0 ? 4 / (gravityValue / GRAVITY_MAP['Earth']) : 10) / pressure;
    
    const isSetupPhase = stepKey === 'SETUP_APPARATUS';

    const isApparatusVisible = (name: string) => {
        const isUsed = usedApparatus.some(u => u.toLowerCase().includes(name.toLowerCase()));
        return (isSetupPhase && isUsed) || !isSetupPhase;
    };

    const getApparatusStyle = (name: string): React.CSSProperties => {
        const isUsed = usedApparatus.some(u => u.toLowerCase().includes(name.toLowerCase()));
        if (isSetupPhase && isUsed) {
            return { animation: 'pop-in 0.5s ease-out forwards' };
        }
        return {};
    };

    const getPendulumStyle = (): React.CSSProperties => {
        const styles: React.CSSProperties = {
            transform: 'rotate(0deg)',
            transition: 'transform 0.5s',
        };
        
        const animations = [];
        const isUsed = usedApparatus.some(u => u.toLowerCase().includes('pendulum'));

        if (isSetupPhase && isUsed) {
            animations.push('pop-in 0.5s ease-out forwards');
        }
        if (!isSetupPhase && (stepKey === 'OBSERVE' || stepKey === 'MEASURE') && pendulumPeriodFactor > 0) {
            animations.push(`swing-damped ${8 * pendulumPeriodFactor}s ease-in-out forwards`);
        }

        if (animations.length > 0) {
            styles.animation = animations.join(', ');
        } else {
            styles.animation = 'none';
        }
        
        return styles;
    };

    return (
        <div className="relative w-full h-80 bg-slate-900/70 rounded-lg border-2 border-slate-700 flex items-center justify-center p-4 perspective-800 overflow-hidden">
             <style>{animationKeyframes}</style>
            <div className="absolute bottom-0 w-full h-1/3 bg-slate-800/50 transform rotate-x-60 origin-bottom"></div>
            <p className="absolute top-4 text-slate-500 text-sm">Lab Stage</p>

            <div className="flex items-end justify-center gap-8 h-full">
                {isTitration && (
                    <>
                        {isApparatusVisible('stand') && (
                            <div style={getApparatusStyle('stand')}>
                                <TripodStandIcon size="xl" />
                            </div>
                        )}
                        {isApparatusVisible('flask') && (
                            <div className="relative" style={getApparatusStyle('flask')}>
                                <FlaskIcon size="xl" />
                                <div className="absolute bottom-2 left-2 right-2 h-1/3 bg-pink-500/30 rounded-b-lg"
                                    style={{
                                        height: stepKey === 'ADD_CHEMICAL' ? '33%' : '0%',
                                        backgroundColor: stepKey === 'OBSERVE' ? 'rgb(219 39 119 / 0.5)' : 'rgb(168 85 247 / 0.4)',
                                        transition: 'all 1s ease-in-out',
                                        opacity: isSetupPhase ? 0 : 1,
                                    }}>
                                </div>
                                <div className="absolute bottom-2 left-2 right-2 h-1/2">
                                    {stepKey === 'HEAT' && <BubbleParticles count={25} intensity="high" />}
                                    {stepKey === 'OBSERVE' && <BubbleParticles count={15} intensity="low" />}
                                </div>
                            </div>
                        )}
                    </>
                )}

                {isPendulum && (
                     <div className="absolute top-4 left-1/2 -translate-x-1/2 w-48 h-full flex justify-center">
                        {isApparatusVisible('stand') && (
                            <div style={getApparatusStyle('stand')}>
                                <div className="absolute w-1 h-3/4 bg-slate-600/70 rounded"></div>
                                <div className="absolute top-0 w-3/4 h-1 bg-slate-600/70 rounded"></div>
                            </div>
                        )}
                        {isApparatusVisible('pendulum') && (
                            <div className="absolute top-1 w-px h-48 bg-slate-400 origin-top" style={getPendulumStyle()}>
                                <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-8 h-8 bg-cyan-400 rounded-full shadow-lg border-2 border-cyan-200"></div>
                            </div>
                        )}
                        
                        {!isSetupPhase && (stepKey === 'OBSERVE' || stepKey === 'MEASURE') &&
                            <div className="absolute bottom-4 left-4 bg-slate-800/80 p-2 rounded-md text-xs text-slate-300 animate-fade-in border border-slate-700">
                                <p className="font-semibold text-cyan-300">Physics Engine:</p>
                                <p><span className="font-medium text-slate-400">Gravity:</span> {gravity} ({gravityValue} m/s²)</p>
                                <p><span className="font-medium text-slate-400">Friction:</span> Active (Causes swing to decay)</p>
                            </div>
                        }
                    </div>
                )}

                {isFluidExperiment && isApparatusVisible('fluid') && (
                     <div className="w-full h-full flex flex-col items-center justify-center" style={getApparatusStyle('fluid')}>
                        <div className="relative w-3/4 h-3/5 border-2 border-slate-600 rounded-md bg-slate-800/30 flex">
                           {/* Chamber 1 */}
                           <div className="relative w-1/2 h-full border-r-2 border-slate-600">
                                <div className="absolute bottom-0 left-0 w-full bg-blue-500/40" style={{
                                    height: stepKey === 'OBSERVE' ? '50%' : '100%',
                                    transition: `height ${fluidFlowDuration}s ease-in-out`
                                }}></div>
                           </div>
                           {/* Chamber 2 */}
                           <div className="relative w-1/2 h-full">
                               <div className="absolute bottom-0 left-0 w-full bg-blue-500/40" style={{
                                    height: stepKey === 'OBSERVE' ? '50%' : '0%',
                                    transition: `height ${fluidFlowDuration}s ease-in-out`
                                }}></div>
                           </div>
                           {/* Valve */}
                           <div className={`absolute left-1/2 -translate-x-1/2 bottom-0 h-4 w-6 bg-slate-500 border-2 border-slate-400 rounded-t-sm transition-colors ${stepKey === 'OBSERVE' && 'bg-green-500'}`}></div>
                        </div>
                        { !isSetupPhase && (stepKey === 'OBSERVE' || stepKey === 'MEASURE') &&
                            <div className="absolute bottom-4 left-4 bg-slate-800/80 p-2 rounded-md text-xs text-slate-300 animate-fade-in border border-slate-700">
                                <p className="font-semibold text-cyan-300">Fluid Dynamics:</p>
                                <p><span className="font-medium text-slate-400">Gravity:</span> {gravity} ({gravityValue} m/s²)</p>
                                <p><span className="font-medium text-slate-400">Pressure:</span> {pressure.toFixed(1)} atm</p>
                                <p><span className="font-medium text-slate-400">Status:</span> {stepKey === 'OBSERVE' ? 'Valve Open, fluid flowing...' : 'Valve Closed'}</p>
                            </div>
                        }
                     </div>
                )}


                 {stepKey === 'HEAT' && (
                    <div className="absolute bottom-10 flex flex-col items-center">
                         <div 
                             className="w-16 h-8 bg-orange-500/50 rounded-full blur-md animate-pulse"
                             style={{
                                transform: `scale(${0.8 + flameIntensity * 0.4})`,
                                animationDuration: `${2 / flameIntensity}s`
                             }}
                         ></div>
                         <BurnerIcon size="lg" />
                    </div>
                 )}
            </div>
        </div>
    );
};

const MolecularView: React.FC<{ stepKey: string }> = ({ stepKey }) => {
    if (stepKey !== 'OBSERVE') return null;

    // Refined keyframes for a smoother, more dynamic animation.
    const keyframes = `
        @keyframes reactant-animation {
            0%, 20% { opacity: 1; transform: scale(1); }
            30% { opacity: 0; transform: scale(0.8); }
            100% { opacity: 0; }
        }
        @keyframes bond-break-glow {
            0%, 15% { filter: none; }
            20% { filter: drop-shadow(0 0 5px #fef08a); } /* Yellow glow */
            25%, 100% { filter: none; }
        }
        @keyframes ion-animation {
            0%, 30% { opacity: 0; }
            40% { opacity: 1; transform: scale(1.1); }
            60% { opacity: 1; transform: scale(1); }
            70% { opacity: 0; transform: scale(0.8); }
            100% { opacity: 0; }
        }
        @keyframes product-animation {
            0%, 70% { opacity: 0; transform: scale(0.8); }
            80%, 100% { opacity: 1; transform: scale(1); }
        }
        @keyframes bond-form-draw {
            0%, 70% { stroke-dashoffset: 20; }
            85%, 100% { stroke-dashoffset: 0; }
        }
    `;

    // Animation duration in seconds
    const animDuration = 9;

    return (
        <div className="bg-slate-900/50 p-4 rounded-lg border border-slate-700">
            <style>{keyframes}</style>
            <h4 className="text-md font-semibold text-cyan-400 mb-2">Molecular View: Reaction Pathway</h4>
            <div className="flex justify-center items-center h-32 bg-slate-800 rounded-md p-2 animate-fade-in overflow-hidden">
                <svg width="100%" height="100%" viewBox="0 0 400 100">
                    {/* --- Animation Groups --- */}

                    {/* Stage 1: Reactants */}
                    <g style={{
                        animation: `reactant-animation ${animDuration}s ease-in-out infinite, bond-break-glow ${animDuration}s ease-in-out infinite`,
                        transformOrigin: '110px 50px'
                    }}>
                        {/* HCl */}
                        <g transform="translate(40, 20)">
                            <line x1="12" y1="40" x2="28" y2="40" stroke="#94A3B8" strokeWidth="2" />
                            <circle cx="10" cy="40" r="5" fill="#E2E8F0" />
                            <circle cx="30" cy="40" r="8" fill="#4ADE80" />
                            <text x="20" y="65" fill="#E2E8F0" fontSize="12" textAnchor="middle">HCl</text>
                        </g>
                        <text x="125" y="55" fill="#94A3B8" fontSize="24">+</text>
                        {/* NaOH */}
                        <g transform="translate(150, 20)">
                             <line x1="10" y1="40" x2="30" y2="40" stroke="#94A3B8" strokeWidth="2" />
                             <line x1="30" y1="40" x2="38" y2="48" stroke="#94A3B8" strokeWidth="1" />
                             <circle cx="10" cy="40" r="6" fill="#60A5FA" />
                             <circle cx="30" cy="40" r="8" fill="#F87171" />
                             <circle cx="38" cy="48" r="3" fill="#E2E8F0" />
                             <text x="24" y="65" fill="#E2E8F0" fontSize="12" textAnchor="middle">NaOH</text>
                        </g>
                    </g>

                    {/* Stage 2: Intermediate Ions (Bond Breaking) */}
                    <g style={{
                        animation: `ion-animation ${animDuration}s ease-in-out infinite`,
                        transformOrigin: 'center'
                    }}>
                        <text x="90"  y="35" fill="#E2E8F0" fontSize="16" textAnchor="middle">H⁺</text>
                        <text x="130" y="35" fill="#4ADE80" fontSize="16" textAnchor="middle">Cl⁻</text>
                        <text x="90"  y="65" fill="#60A5FA" fontSize="16" textAnchor="middle">Na⁺</text>
                        <text x="130" y="65" fill="#F87171" fontSize="16" textAnchor="middle">OH⁻</text>
                    </g>

                    {/* Stage 3: Products (Bond Forming) */}
                    <g style={{
                        animation: `product-animation ${animDuration}s ease-in-out infinite`,
                        transformOrigin: '310px 50px'
                    }}>
                        <text x="210" y="55" fill="#94A3B8" fontSize="24">&rarr;</text>
                        {/* H₂O */}
                        <g transform="translate(240, 20)">
                            <line x1="20" y1="30" x2="5" y2="45" stroke="#94A3B8" strokeWidth="2" strokeDasharray="20" style={{ animation: `bond-form-draw ${animDuration}s ease-in-out infinite` }}/>
                            <line x1="20" y1="30" x2="35" y2="45" stroke="#94A3B8" strokeWidth="2" strokeDasharray="20" style={{ animation: `bond-form-draw ${animDuration}s ease-in-out infinite`, animationDelay: '0.1s' }}/>
                            <circle cx="20" cy="30" r="12" fill="#F87171" />
                            <circle cx="5" cy="45" r="5" fill="#E2E8F0" />
                            <circle cx="35" cy="45" r="5" fill="#E2E8F0" />
                            <text x="20" y="65" fill="#E2E8F0" fontSize="12" textAnchor="middle">H₂O</text>
                        </g>
                        <text x="310" y="55" fill="#94A3B8" fontSize="24">+</text>
                        <text x="340" y="55" fill="#60A5FA" fontSize="16" textAnchor="middle">Na⁺</text>
                        <text x="370" y="55" fill="#4ADE80" fontSize="16" textAnchor="middle">Cl⁻</text>
                    </g>
                </svg>
            </div>
             <p className="text-xs text-slate-500 mt-2 text-center">Animation showing bonds breaking (ions forming) and new bonds forming.</p>
        </div>
    );
};

const ReactionMonitor: React.FC<{ stepKey: string; reactionSpeed: number; ambientTemperature: number; }> = ({ stepKey, reactionSpeed, ambientTemperature }) => {
    const [ph, setPh] = useState(2.0);
    const [temperature, setTemperature] = useState(25.0);
    const [concentration, setConcentration] = useState(0.1);

    useEffect(() => {
        if (stepKey === 'OBSERVE') {
            const initialPh = 2.0;
            const initialTemp = ambientTemperature;
            const initialConc = 0.1;
            setPh(initialPh);
            setTemperature(initialTemp);
            setConcentration(initialConc);

            const interval = setInterval(() => {
                setPh(prev => {
                    if (prev >= 12) return 12;
                    if (prev < 6.5) return prev + 0.2;
                    if (prev < 7.5) return prev + 1.0;
                    return prev + 0.15;
                });
                setTemperature(prev => Math.min(initialTemp + 3.5, prev + 0.1));
                setConcentration(prev => Math.max(0, prev - 0.005));
            }, 700 / reactionSpeed);

            const timeout = setTimeout(() => clearInterval(interval), 8000 / reactionSpeed);

            return () => {
                clearInterval(interval);
                clearTimeout(timeout);
            };
        }
    }, [stepKey, reactionSpeed, ambientTemperature]);

    if (stepKey !== 'OBSERVE') return null;
    
    const getPhColor = (currentPh: number) => {
        if (currentPh < 3) return 'bg-red-500';
        if (currentPh < 6) return 'bg-orange-500';
        if (currentPh < 8) return 'bg-green-500';
        if (currentPh < 11) return 'bg-blue-500';
        return 'bg-indigo-500';
    };

    return (
        <div className="bg-slate-900/50 p-4 rounded-lg border border-slate-700 animate-fade-in space-y-4">
            <h4 className="text-md font-semibold text-cyan-400">Real-time Monitoring</h4>
            
            <div className="space-y-3">
                <div className="flex items-center gap-3">
                    <PhIcon />
                    <span className="text-sm font-medium text-slate-300 w-24">pH Level</span>
                    <div className="w-full bg-slate-700 rounded-full h-2.5">
                        <div className={`${getPhColor(ph)} h-2.5 rounded-full transition-all duration-500`} style={{ width: `${(ph / 14) * 100}%` }}></div>
                    </div>
                    <span className="text-sm font-mono text-cyan-300 w-12 text-right">{ph.toFixed(1)}</span>
                </div>
                
                <div className="flex items-center gap-3">
                    <TemperatureIcon />
                    <span className="text-sm font-medium text-slate-300 w-24">Temperature</span>
                    <div className="w-full bg-slate-700 rounded-full h-2.5">
                        <div className="bg-orange-500 h-2.5 rounded-full transition-all duration-500" style={{ width: `${Math.max(0, (temperature - ambientTemperature) / 5 * 100)}%` }}></div>
                    </div>
                    <span className="text-sm font-mono text-cyan-300 w-12 text-right">{temperature.toFixed(1)}°C</span>
                </div>

                <div className="flex items-center gap-3">
                    <ConcentrationIcon />
                    <span className="text-sm font-medium text-slate-300 w-24">Reactant Conc.</span>
                    <div className="w-full bg-slate-700 rounded-full h-2.5">
                        <div className="bg-purple-500 h-2.5 rounded-full transition-all duration-500" style={{ width: `${(concentration / 0.1) * 100}%` }}></div>
                    </div>
                    <span className="text-sm font-mono text-cyan-300 w-12 text-right">{concentration.toFixed(3)} M</span>
                </div>
            </div>
        </div>
    );
};

const MIXER_CHEMICALS = [
    { name: 'Water', formula: 'H₂O', color: 'bg-blue-500/30', type: 'solvent' },
    { name: 'HCl', formula: 'HCl', color: 'bg-purple-500/30', type: 'acid' },
    { name: 'NaOH', formula: 'NaOH', color: 'bg-indigo-500/30', type: 'base' },
    { name: 'Phenolphthalein', formula: 'C₂₀H₁₄O₄', color: 'bg-pink-500/50', type: 'indicator' },
];

const ChemicalMixer: React.FC<{
    mixture: Record<string, { name: string; amount: number; type: string }>;
    onMixtureChange: React.Dispatch<React.SetStateAction<Record<string, { name: string; amount: number; type: string }>>>;
}> = ({ mixture, onMixtureChange }) => {
    const [lastAdded, setLastAdded] = useState<string | null>(null);

    const totalAmount = useMemo(() => Object.values(mixture).reduce((sum, chem) => sum + chem.amount, 0), [mixture]);

    const handleAddChemical = (chemical: typeof MIXER_CHEMICALS[0]) => {
        onMixtureChange(prev => {
            const existing = prev[chemical.formula];
            return {
                ...prev,
                [chemical.formula]: {
                    name: chemical.name,
                    amount: (existing?.amount || 0) + 10, // Add 10mL units
                    type: chemical.type,
                }
            };
        });
        setLastAdded(chemical.formula);
        setTimeout(() => setLastAdded(null), 500);
    };

    const handleReset = () => {
        onMixtureChange({});
    };
    
    const mixtureColor = useMemo(() => {
        const hasIndicator = !!mixture['C₂₀H₁₄O₄'];
        if (!hasIndicator) return 'bg-blue-500/30'; // Default to water color or clear

        const acidAmount = mixture['HCl']?.amount || 0;
        const baseAmount = mixture['NaOH']?.amount || 0;

        return baseAmount > acidAmount ? 'bg-pink-500/50' : 'bg-blue-500/30';
    }, [mixture]);

     return (
        <div className="bg-slate-900/50 p-4 rounded-lg border border-slate-700 space-y-4">
            <div className="flex justify-between items-center">
                <h4 className="text-md font-semibold text-cyan-400">Chemical Mixer</h4>
                <button onClick={handleReset} className="flex items-center gap-1.5 text-xs font-semibold bg-slate-700 hover:bg-slate-600 px-3 py-1.5 rounded-md text-slate-300 hover:text-white transition-colors">
                    <RefreshIcon size="sm" />
                    Reset Mixer
                </button>
            </div>
            <div className="flex gap-4">
                {/* Beaker visualization */}
                <div className="relative w-24 h-32 bg-slate-800 border-2 border-slate-600 rounded-b-lg rounded-t-sm p-1 flex flex-col-reverse">
                    {Object.entries(mixture).map(([formula, chem]) => (
                         <div key={formula} className={`${MIXER_CHEMICALS.find(c => c.formula === formula)?.color} w-full transition-all duration-500`} style={{ height: `${(chem.amount / Math.max(100, totalAmount)) * 100}%` }}></div>
                    ))}
                    <div className={`absolute inset-0 transition-colors duration-500 ${mixtureColor} ${lastAdded ? 'animate-pulse' : ''}`}></div>
                    <span className="absolute top-1 right-1 text-xs font-mono text-slate-400">{totalAmount}mL</span>
                </div>

                {/* Chemical buttons */}
                <div className="flex-1 grid grid-cols-2 gap-2">
                    {MIXER_CHEMICALS.map(chemical => (
                        <button key={chemical.name} onClick={() => handleAddChemical(chemical)} className="p-2 bg-slate-700 hover:bg-slate-600 rounded-md text-left flex items-center gap-2">
                            <PlusIcon />
                            <div>
                                <p className="text-sm font-semibold text-slate-200">{chemical.name}</p>
                                <p className="text-xs font-mono text-slate-400">{chemical.formula}</p>
                            </div>
                        </button>
                    ))}
                </div>
            </div>
        </div>
    );
};

const ResultsTable: React.FC<{ markdownContent: string }> = ({ markdownContent }) => {
    const parseMarkdownTable = (markdown: string): { headers: string[]; rows: string[][] } | null => {
        const lines = markdown.trim().split('\n').filter(line => line.includes('|'));
        if (lines.length < 2) return null; // Needs at least header and separator

        const parseRow = (rowString: string) => {
            const row = rowString.trim();
            const cleanedRow = row.startsWith('|') && row.endsWith('|') ? row.substring(1, row.length - 1) : row;
            return cleanedRow.split('|').map(cell => cell.trim());
        };

        try {
            const headers = parseRow(lines[0]);
            if (headers.length === 0) return null;
            
            const rows = lines.slice(2).map(parseRow);
            if (rows.length === 0 || rows.some(r => r.length !== headers.length)) return null;

            return { headers, rows };
        } catch (e) {
            console.error("Failed to parse markdown table:", e);
            return null;
        }
    };
    
    const getPhColorClass = (ph: number): string => {
        if (isNaN(ph)) return '';
        if (ph < 3) return 'text-red-400 font-bold';
        if (ph >= 3 && ph < 6) return 'text-orange-400 font-bold';
        if (ph >= 6 && ph < 8) return 'text-green-400 font-bold';
        if (ph >= 8 && ph <= 11) return 'text-blue-400 font-bold';
        if (ph > 11) return 'text-indigo-400 font-bold';
        return '';
    };

    const tableData = parseMarkdownTable(markdownContent);

    if (!tableData) {
        return <div className="prose prose-invert max-w-none" dangerouslySetInnerHTML={{ __html: markdownContent.replace(/\|/g, ' | ') }} />;
    }

    const { headers, rows } = tableData;
    const phColumnIndex = headers.findIndex(h => h.toLowerCase().trim() === 'ph');

    return (
        <div className="overflow-x-auto">
            <table className="min-w-full text-left border-collapse">
                <thead>
                    <tr>
                        {headers.map((header, index) => (
                            <th key={index} className="border border-slate-600 bg-slate-700 p-2 px-3 font-semibold text-slate-200">{header}</th>
                        ))}
                    </tr>
                </thead>
                <tbody>
                    {rows.map((row, rowIndex) => (
                        <tr key={rowIndex} className="bg-slate-800">
                            {row.map((cell, cellIndex) => {
                                let cellClasses = 'border border-slate-600 p-2 px-3 text-slate-300';
                                if (cellIndex === phColumnIndex) {
                                    const phValue = parseFloat(cell);
                                    cellClasses = `${cellClasses} ${getPhColorClass(phValue)}`;
                                }
                                return (
                                    <td key={cellIndex} className={cellClasses}>
                                        {cell}
                                    </td>
                                );
                            })}
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};


const ExperimentView: React.FC<ExperimentViewProps> = ({ experimentName, subject, onBack }) => {
  const [details, setDetails] = useState<ExperimentDetails | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  
  const [currentStep, setCurrentStep] = useState(0);
  const [usedApparatus, setUsedApparatus] = useState<string[]>([]);
  const [results, setResults] = useState<ExperimentResult | null>(null);
  const [generatingResults, setGeneratingResults] = useState(false);

  // State for expandable procedure steps
  const [expandedStep, setExpandedStep] = useState<number | null>(null);

  // Simulation parameters
  const [gravity, setGravity] = useState<GravityOption>('Earth');
  const [reactionSpeed, setReactionSpeed] = useState(1);
  const [pressure, setPressure] = useState(1);
  const [ambientTemperature, setAmbientTemperature] = useState(25);
  const [flameIntensity, setFlameIntensity] = useState(1);
  
  // Lifted state from ChemicalMixer
  const [mixture, setMixture] = useState<Record<string, { name: string; amount: number; type: string }>>({});

  // State for save/load functionality
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');
  const [isLoadable, setIsLoadable] = useState(false);

  // State for video generation
  const [videoState, setVideoState] = useState<{
    status: 'idle' | 'generating' | 'success' | 'error';
    url: string | null;
    error: string | null;
    loadingMessage: string;
  }>({
    status: 'idle',
    url: null,
    error: null,
    loadingMessage: VIDEO_LOADING_MESSAGES[0],
  });
  const [apiKeySelected, setApiKeySelected] = useState(false);


  const isFluidExperiment = subject === 'Physics' && experimentName.toLowerCase().includes('fluid');
  const isPendulumExperiment = subject === 'Physics' && experimentName.toLowerCase().includes('pendulum');
  const isTitrationExperiment = subject === 'Chemistry' && experimentName.toLowerCase().includes('titration');
  const isChemicalExperiment = subject === 'Chemistry';

  const resetSimulation = useCallback(() => {
    setCurrentStep(0);
    setUsedApparatus([]);
    setResults(null);
    setGeneratingResults(false);
    setGravity('Earth');
    setReactionSpeed(1);
    setPressure(1);
    setAmbientTemperature(25);
    setFlameIntensity(1);
    setMixture({});
    setExpandedStep(null);
    setVideoState({ status: 'idle', url: null, error: null, loadingMessage: VIDEO_LOADING_MESSAGES[0] });
  }, []);

  useEffect(() => {
    const checkApiKey = async () => {
        if ((window as any).aistudio && await (window as any).aistudio.hasSelectedApiKey()) {
            setApiKeySelected(true);
        }
    };
    checkApiKey();
  }, []);

  useEffect(() => {
    // Check for loadable state when component mounts or experiment changes
    const savedDataString = localStorage.getItem('virtualLabSaveState');
    if (savedDataString) {
      try {
        const savedState: SavedState = JSON.parse(savedDataString);
        setIsLoadable(savedState.experimentName === experimentName);
      } catch {
        setIsLoadable(false);
      }
    } else {
      setIsLoadable(false);
    }
  }, [experimentName]);

  useEffect(() => {
    const fetchDetails = async () => {
      setLoading(true);
      setError(null);
      resetSimulation();
      try {
        const data = await generateExperimentDetails(experimentName);
        if (data) {
          setDetails(data);
        } else {
          setError("Failed to load experiment details. The AI model might be unavailable. Please try again later.");
        }
      } catch (e) {
        setError("An unexpected error occurred while fetching experiment details.");
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    fetchDetails();
  }, [experimentName, resetSimulation]);
  
  const handleSaveState = () => {
    setSaveStatus('saving');
    const stateToSave: SavedState = {
        experimentName,
        currentStep,
        usedApparatus,
        results,
        gravity,
        reactionSpeed,
        pressure,
        ambientTemperature,
        flameIntensity,
        mixture,
    };
    localStorage.setItem('virtualLabSaveState', JSON.stringify(stateToSave));
    
    setTimeout(() => {
        setSaveStatus('saved');
        setIsLoadable(true); // After saving, it's definitely loadable
        setTimeout(() => setSaveStatus('idle'), 2000);
    }, 500);
  };

  const handleLoadState = () => {
      const savedDataString = localStorage.getItem('virtualLabSaveState');
      if (savedDataString) {
          try {
              const savedState: SavedState = JSON.parse(savedDataString);
              if (savedState.experimentName === experimentName) {
                  setCurrentStep(savedState.currentStep);
                  setUsedApparatus(savedState.usedApparatus);
                  setResults(savedState.results);
                  setGravity(savedState.gravity);
                  setReactionSpeed(savedState.reactionSpeed);
                  setPressure(savedState.pressure);
                  setAmbientTemperature(savedState.ambientTemperature);
                  setFlameIntensity(savedState.flameIntensity || 1); // Default to 1 if not in saved state
                  setMixture(savedState.mixture);
                  alert('Simulation state loaded successfully!');
              } else {
                  alert(`A saved state was found for "${savedState.experimentName}", but you are currently in the "${experimentName}" experiment.`);
              }
          } catch (e) {
              alert('Failed to load simulation state. The saved data might be corrupted.');
              console.error("Failed to parse saved state:", e);
          }
      } else {
          alert('No saved simulation state found.');
      }
  };

  const handleSelectKey = async () => {
    if ((window as any).aistudio) {
        await (window as any).aistudio.openSelectKey();
        // Optimistically assume the user selected a key, which allows them to immediately try generating a video.
        // If the key is invalid, the error handling in `handleGenerateVideo` will catch it.
        setApiKeySelected(true);
    }
  };

  const handleGenerateVideo = async () => {
    if (!details || !results) return;

    setVideoState({
        status: 'generating',
        url: null,
        error: null,
        loadingMessage: VIDEO_LOADING_MESSAGES[0],
    });

    const messageInterval = setInterval(() => {
        setVideoState(prevState => ({
            ...prevState,
            loadingMessage: VIDEO_LOADING_MESSAGES[
                (VIDEO_LOADING_MESSAGES.indexOf(prevState.loadingMessage) + 1) % VIDEO_LOADING_MESSAGES.length
            ],
        }));
    }, 4000);

    try {
        const videoUrl = await generateExperimentVideo(experimentName, details, results);
        setVideoState({
            status: 'success',
            url: videoUrl,
            error: null,
            loadingMessage: '',
        });
    } catch (e: any) {
        let errorMessage = "An unexpected error occurred during video generation.";
        if (e.message && e.message.includes("Requested entity was not found")) {
            errorMessage = "Your API Key is invalid. Please select a valid key and try again.";
            setApiKeySelected(false); // Reset key state
        }
        setVideoState({
            status: 'error',
            url: null,
            error: errorMessage,
            loadingMessage: '',
        });
    } finally {
        clearInterval(messageInterval);
    }
  };

  const handleApparatusClick = (apparatusName: string) => {
    if (details && details.procedureSteps[currentStep]?.key === 'SETUP_APPARATUS') {
      setUsedApparatus(prev => [...prev, apparatusName]);
      if (usedApparatus.length + 1 === details.apparatus.length) {
        setCurrentStep(prev => prev + 1);
      }
    }
  };

  const handleNextStep = () => {
    if (details && currentStep < details.procedureSteps.length) {
      setCurrentStep(prev => prev + 1);
      setExpandedStep(null); // Collapse any open explanation on step change
    }
  };

  const handleGenerateResults = async () => {
    if (details) {
      setGeneratingResults(true);
      const data = await generateExperimentResults(experimentName, details.theory);
      if (data) {
        setResults(data);
      } else {
        // Handle error case, maybe show a toast
      }
      setGeneratingResults(false);
    }
  };

  const handleToggleExplanation = (index: number) => {
    setExpandedStep(prev => (prev === index ? null : index));
  };

  const currentStepKey = useMemo(() => {
    if (!details || currentStep >= details.procedureSteps.length) return '';
    return details.procedureSteps[currentStep].key;
  }, [details, currentStep]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-64">
        <Spinner size="lg" />
        <p className="mt-4 text-slate-400">Preparing your lab bench...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center p-8 bg-red-900/20 border border-red-500 rounded-lg">
        <h3 className="text-2xl font-bold text-red-400 mb-2">Error</h3>
        <p className="text-red-300">{error}</p>
        <button onClick={onBack} className="mt-6 bg-cyan-500 hover:bg-cyan-600 text-white font-bold py-2 px-4 rounded-lg">
          Back to Dashboard
        </button>
      </div>
    );
  }

  if (!details) return null;

  const isSimulationComplete = currentStep >= details.procedureSteps.length;
  const saveButtonText = {
    idle: 'Save Simulation',
    saving: 'Saving...',
    saved: 'Saved!'
  };

  return (
    <div className="animate-fade-in">
        <button onClick={onBack} className="flex items-center gap-2 text-cyan-400 hover:text-cyan-300 transition-colors mb-4">
          <BackIcon />
          <span>Back to Experiments</span>
        </button>
        
        <div className="flex justify-between items-center mb-6 border-b border-slate-700 pb-4">
            <h2 className="text-3xl font-bold">{details.aim}</h2>
            <div className="flex items-center gap-4 flex-shrink-0">
                <button 
                    onClick={handleSaveState}
                    disabled={saveStatus !== 'idle'}
                    className={`flex items-center gap-2 px-3 py-2 text-sm font-semibold rounded-lg transition-all duration-200 ${
                    saveStatus === 'saved'
                        ? 'bg-green-500 text-white'
                        : 'bg-slate-700 text-slate-200 hover:bg-slate-600 disabled:opacity-50'
                    }`}
                >
                    <SaveIcon size="sm" />
                    {saveButtonText[saveStatus]}
                </button>
                <button
                    onClick={handleLoadState}
                    disabled={!isLoadable}
                    className="flex items-center gap-2 px-3 py-2 text-sm font-semibold rounded-lg bg-slate-700 text-slate-200 hover:bg-slate-600 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    <LoadIcon size="sm" />
                    Load Simulation
                </button>
            </div>
        </div>

      <p className="text-slate-400 mb-8">{details.theory}</p>

      <div className="grid md:grid-cols-3 gap-8">
        
        {/* Left Column: Procedure & Apparatus */}
        <div className="md:col-span-2 space-y-8">
          {/* Procedure */}
          <div className="bg-slate-800/50 p-6 rounded-lg border border-slate-700">
            <h3 className="text-xl font-semibold text-cyan-400 mb-4">Procedure</h3>
            <ul className="space-y-2">
              {details.procedureSteps.map((step, index) => (
                <li key={index} className={`p-3 rounded-md transition-all ${
                  index === currentStep ? 'bg-cyan-500/10' : ''
                }`}>
                   <div className="flex items-start gap-3">
                        <div className={`mt-1 h-5 w-5 flex-shrink-0 rounded-full flex items-center justify-center font-bold text-xs ${
                            index < currentStep ? 'bg-green-500 text-white' : index === currentStep ? 'bg-cyan-500 text-white' : 'bg-slate-700 text-slate-300'
                        }`}>
                            {index < currentStep ? <StepCheckIcon/> : index + 1}
                        </div>
                        <p className={`flex-grow ${
                            index < currentStep ? 'text-slate-500 line-through' : index === currentStep ? 'text-slate-100' : 'text-slate-400'
                        }`}>
                            {step.step}
                        </p>
                        {step.explanation && (
                            <button 
                                onClick={() => handleToggleExplanation(index)} 
                                className="flex-shrink-0 text-slate-400 hover:text-cyan-400 p-1 rounded-full hover:bg-slate-700 transition-colors"
                                aria-expanded={expandedStep === index}
                                aria-controls={`explanation-${index}`}
                                title="View explanation"
                            >
                                <InfoIcon size="sm" /> 
                            </button>
                        )}
                    </div>
                    <div 
                        className="overflow-hidden transition-all duration-500 ease-in-out"
                        style={{ maxHeight: expandedStep === index ? '500px' : '0' }}
                        id={`explanation-${index}`}
                    >
                        {step.explanation && (
                            <div className="mt-2 ml-8 pl-4 py-3 border-l-4 border-cyan-500 bg-slate-800/60 rounded-r-md">
                                <p className="text-sm text-slate-200">{step.explanation}</p>
                            </div>
                        )}
                    </div>
                </li>
              ))}
            </ul>

            {!isSimulationComplete && currentStepKey !== 'SETUP_APPARATUS' && (
              <button onClick={handleNextStep} className="mt-6 bg-cyan-500 hover:bg-cyan-600 text-white font-bold py-2 px-4 rounded-lg transition-transform transform hover:scale-105">
                Next Step
              </button>
            )}

            {isSimulationComplete && !results && (
                 <button 
                    onClick={handleGenerateResults} 
                    disabled={generatingResults}
                    className="mt-6 w-full bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-4 rounded-lg transition-transform transform hover:scale-105 flex items-center justify-center gap-3 disabled:bg-slate-600 disabled:cursor-not-allowed">
                    {generatingResults ? <><Spinner size="sm" /> Generating Results...</> : 'Generate Experiment Results'}
                 </button>
            )}
          </div>

           {/* Lab Bench */}
          <div className="bg-slate-800/50 p-6 rounded-lg border border-slate-700">
             <h3 className="text-xl font-semibold text-cyan-400 mb-4">Lab Bench</h3>
             <LabStage 
                stepKey={currentStepKey} 
                experimentName={experimentName} 
                subject={subject} 
                gravity={gravity}
                pressure={pressure}
                flameIntensity={flameIntensity}
                usedApparatus={usedApparatus}
             />
          </div>

          {isTitrationExperiment && currentStepKey === 'OBSERVE' && (
              <ReactionMonitor 
                stepKey={currentStepKey} 
                reactionSpeed={reactionSpeed}
                ambientTemperature={ambientTemperature}
              />
          )}

           {isTitrationExperiment && currentStepKey === 'OBSERVE' && <MolecularView stepKey={currentStepKey} />}
          
        </div>
        
        {/* Right Column: Info & Controls */}
        <div className="md:col-span-1 space-y-6">
            {(isPendulumExperiment || isFluidExperiment) && <GravityControl selected={gravity} onSelect={setGravity} />}
            <SimulationControls
                subject={subject}
                experimentName={experimentName}
                procedureSteps={details.procedureSteps}
                reactionSpeed={reactionSpeed}
                onReactionSpeedChange={setReactionSpeed}
                pressure={pressure}
                onPressureChange={setPressure}
                ambientTemperature={ambientTemperature}
                onAmbientTemperatureChange={setAmbientTemperature}
                flameIntensity={flameIntensity}
                onFlameIntensityChange={setFlameIntensity}
            />

             {/* Apparatus Panel */}
            <div className="bg-slate-800/50 p-6 rounded-lg border border-slate-700">
                <h3 className="text-xl font-semibold text-cyan-400 mb-1">Apparatus</h3>
                {currentStepKey === 'SETUP_APPARATUS' && (
                    <p className="text-slate-400 mb-4 text-sm">Click on all apparatus items to set up your experiment.</p>
                )}
                <div className="flex flex-wrap gap-4 justify-center">
                    {details.apparatus.map(item => {
                        const isHighlighted = !usedApparatus.includes(item) && (currentStepKey === 'SETUP_APPARATUS' || (details.procedureSteps[currentStep]?.step.toLowerCase().includes(item.toLowerCase())));
                        return (
                            <ApparatusItem
                                key={item}
                                name={item}
                                onClick={() => handleApparatusClick(item)}
                                isUsed={usedApparatus.includes(item)}
                                isHighlighted={isHighlighted}
                                isSetupPhase={currentStepKey === 'SETUP_APPARATUS'}
                            />
                        );
                    })}
                </div>
            </div>

          {isChemicalExperiment && <ChemicalMixer mixture={mixture} onMixtureChange={setMixture} />}

          {/* Precautions */}
          <div className="bg-yellow-900/20 p-4 rounded-lg border border-yellow-500/50">
            <h4 className="flex items-center gap-2 text-md font-semibold text-yellow-300 mb-2">
              <WarningIcon />
              Precautions
            </h4>
            <ul className="list-disc list-inside space-y-1 text-sm text-yellow-200/80">
              {details.precautions.map((p, i) => <li key={i}>{p}</li>)}
            </ul>
          </div>
        </div>

        {/* Results Section */}
        {results && (
          <div className="md:col-span-3 bg-slate-800 p-6 rounded-lg border border-slate-700 animate-fade-in">
             <h3 className="text-xl font-semibold text-cyan-400 mb-4">Results</h3>
             <div className="space-y-6">
                <div>
                    <h4 className="text-lg font-semibold text-slate-100 mb-2">Observations</h4>
                    <ResultsTable markdownContent={results.observations} />
                    <ResultsCharts markdownContent={results.observations} />
                </div>

                <div className="prose prose-invert max-w-none">
                    <h4>Calculations</h4>
                    <p>{results.calculations}</p>

                    <h4>Conclusion</h4>
                    <p>{results.conclusion}</p>
                </div>

                {/* Video Summary Section */}
                <div className="border-t border-slate-700 pt-6">
                    <h4 className="text-lg font-semibold text-slate-100 mb-4">Video Summary</h4>
                    {videoState.status === 'idle' && (
                        <div className="flex flex-col sm:flex-row items-center gap-4">
                             <button 
                                onClick={handleGenerateVideo}
                                disabled={!apiKeySelected}
                                className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2 text-sm font-semibold rounded-lg bg-cyan-500 text-white hover:bg-cyan-600 disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                <VideoIcon size="sm"/>
                                Generate Video Summary
                            </button>
                            {!apiKeySelected && (
                                <div className="text-sm text-slate-400 flex flex-col sm:flex-row items-center gap-2">
                                    <span>Requires a user-managed API key.</span>
                                    <button onClick={handleSelectKey} className="flex items-center gap-1.5 text-cyan-400 hover:text-cyan-300 font-semibold underline">
                                        <KeyIcon size="sm" />
                                        Select API Key
                                    </button>
                                </div>
                            )}
                        </div>
                    )}

                    {videoState.status === 'generating' && (
                        <div className="flex flex-col items-center text-center p-4 bg-slate-900/50 rounded-lg">
                            <Spinner />
                            <p className="mt-3 font-semibold text-cyan-300">{videoState.loadingMessage}</p>
                            <p className="text-sm text-slate-400">Video generation can take a few minutes. Please wait...</p>
                        </div>
                    )}
                    
                    {videoState.status === 'error' && (
                         <div className="text-center p-4 bg-red-900/20 border border-red-500 rounded-lg">
                            <h5 className="font-bold text-red-400 mb-1">Video Generation Failed</h5>
                            <p className="text-red-300 text-sm">{videoState.error}</p>
                             <button 
                                onClick={handleGenerateVideo}
                                disabled={!apiKeySelected}
                                className="mt-3 flex mx-auto items-center justify-center gap-2 px-3 py-1.5 text-xs font-semibold rounded-lg bg-cyan-500 text-white hover:bg-cyan-600 disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                Try Again
                            </button>
                        </div>
                    )}

                    {videoState.status === 'success' && videoState.url && (
                        <div className="text-center p-4 bg-green-900/20 border border-green-500 rounded-lg">
                            <h5 className="font-bold text-green-400 mb-2">Video Summary Ready!</h5>
                             <a 
                                href={`${videoState.url}&key=${process.env.API_KEY}`}
                                download={`${experimentName.replace(/\s+/g, '_')}_Summary.mp4`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex items-center justify-center gap-2 px-4 py-2 text-sm font-semibold rounded-lg bg-green-500 text-white hover:bg-green-600"
                            >
                                <DownloadIcon size="sm"/>
                                Download Video
                            </a>
                        </div>
                    )}
                </div>
             </div>
          </div>
        )}

      </div>
    </div>
  );
};

export default ExperimentView;