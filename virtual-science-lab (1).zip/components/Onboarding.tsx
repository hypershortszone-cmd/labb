import React, { useState } from 'react';
import { BOARDS, CLASSES, SUBJECTS } from '../constants';
import { OnboardingData, Board, ClassLevel, Subject } from '../types';
import { CheckIcon, ChevronDownIcon } from './icons';

interface OnboardingProps {
  onComplete: (data: OnboardingData) => void;
}

// Fix: Moved SelectionCard outside of the Onboarding component to prevent it from being recreated on every render.
const SelectionCard = <T extends string>({ title, options, selected, onSelect }: { title: string, options: T[], selected: T, onSelect: (value: T) => void }) => (
  <div className="bg-slate-800 p-6 rounded-lg shadow-lg w-full">
    <h3 className="text-lg font-semibold text-cyan-400 mb-4">{title}</h3>
    <div className="grid grid-cols-2 gap-3">
      {options.map((option) => (
        <button
          key={option}
          onClick={() => onSelect(option)}
          className={`px-4 py-2 rounded-md text-sm font-medium transition-all duration-200 flex items-center justify-center gap-2 ${
            selected === option
              ? 'bg-cyan-500 text-white shadow-md'
              : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
          }`}
        >
          {selected === option && <CheckIcon />}
          {option}
        </button>
      ))}
    </div>
  </div>
);

const Onboarding: React.FC<OnboardingProps> = ({ onComplete }) => {
  const [board, setBoard] = useState<Board>(BOARDS[0]);
  const [classLevel, setClassLevel] = useState<ClassLevel>(CLASSES[0]);
  const [subject, setSubject] = useState<Subject>(SUBJECTS[0]);

  const handleSubmit = () => {
    onComplete({ board, classLevel, subject });
  };

  return (
    <div className="max-w-4xl mx-auto flex flex-col items-center text-center">
      <div className="bg-slate-800/50 p-8 rounded-xl shadow-2xl backdrop-blur-lg border border-slate-700">
        <h2 className="text-4xl font-bold mb-2 text-white">Welcome to the Lab!</h2>
        <p className="text-slate-400 mb-8 max-w-2xl">
          Let's set up your virtual lab bench. Select your board, class, and the subject you want to explore today.
        </p>
        <div className="grid md:grid-cols-3 gap-6 text-left w-full mb-8">
          {/* Fix: Wrapped state setters in lambdas to resolve type inference issue with the generic component. */}
          <SelectionCard title="Board" options={BOARDS} selected={board} onSelect={(value) => setBoard(value)} />
          <SelectionCard title="Class" options={CLASSES} selected={classLevel} onSelect={(value) => setClassLevel(value)} />
          <SelectionCard title="Subject" options={SUBJECTS} selected={subject} onSelect={(value) => setSubject(value)} />
        </div>
        <button
          onClick={handleSubmit}
          className="bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-8 rounded-lg shadow-lg transition-transform transform hover:scale-105"
        >
          Start Learning
        </button>
      </div>
    </div>
  );
};

export default Onboarding;