import { GoogleGenAI, Type } from "@google/genai";
import { ExperimentDetails, ExperimentResult } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

export const generateExperimentDetails = async (experimentName: string): Promise<ExperimentDetails | null> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Generate the details for a high school science experiment named "${experimentName}". Provide the response in JSON format. For the procedure, create a 'procedureSteps' array of objects, where each object has a 'step' description, a 'key' indicating the action type (e.g., 'SETUP_APPARATUS', 'ADD_CHEMICAL'), and an 'explanation' field that provides a detailed explanation of the scientific purpose or context for this step, clarifying why it's important.`,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        aim: { type: Type.STRING, description: "The main objective of the experiment." },
                        theory: { type: Type.STRING, description: "The scientific principles and background theory behind the experiment." },
                        apparatus: { type: Type.ARRAY, items: { type: Type.STRING }, description: "A list of all equipment and materials needed." },
                        procedureSteps: { 
                            type: Type.ARRAY, 
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    step: { type: Type.STRING, description: "A single, detailed step for the procedure." },
                                    key: { type: Type.STRING, description: "An action key for the simulation (e.g., SETUP_APPARATUS, ADD_CHEMICAL, HEAT, MEASURE, OBSERVE)." },
                                    explanation: { type: Type.STRING, description: "A detailed explanation of the scientific purpose, context, or importance of this step." }
                                },
                                required: ["step", "key", "explanation"]
                            },
                            description: "A detailed, step-by-step procedure to conduct the experiment." 
                        },
                        precautions: { type: Type.ARRAY, items: { type: Type.STRING }, description: "A list of safety precautions to be followed." }
                    },
                    required: ["aim", "theory", "apparatus", "procedureSteps", "precautions"]
                }
            }
        });

        const jsonString = response.text.trim();
        // A simple fix for potential markdown in the response
        const cleanedJsonString = jsonString.replace(/^```json\s*|```$/g, '');
        const data = JSON.parse(cleanedJsonString);
        return data as ExperimentDetails;

    } catch (error) {
        console.error("Error generating experiment details:", error);
        return null;
    }
};

export const generateExperimentResults = async (experimentName: string, theory: string): Promise<ExperimentResult | null> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Based on the standard procedure and theory for the "${experimentName}" experiment, generate a typical result set. The theory is: "${theory}". Provide the response in JSON format. The 'observations' field should be a markdown-formatted table.`,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        observations: { type: Type.STRING, description: "A markdown-formatted table with typical observations and readings." },
                        calculations: { type: Type.STRING, description: "Step-by-step sample calculations based on the observations." },
                        conclusion: { type: Type.STRING, description: "A concise conclusion derived from the experiment's results." }
                    },
                    required: ["observations", "calculations", "conclusion"]
                }
            }
        });
        
        const jsonString = response.text.trim();
        const cleanedJsonString = jsonString.replace(/^```json\s*|```$/g, '');
        const data = JSON.parse(cleanedJsonString);
        return data as ExperimentResult;

    } catch (error) {
        console.error("Error generating experiment results:", error);
        return null;
    }
};

export const generateExperimentVideo = async (
  experimentName: string,
  details: ExperimentDetails,
  results: ExperimentResult
): Promise<string> => {
  // Create a new instance to ensure the latest API key is used for Veo.
  const videoAi = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

  const procedureSummary = details.procedureSteps
    .slice(0, 3) // Take first 3 steps
    .map((step, index) => `${index + 1}. ${step.step}`)
    .join(' ');

  const prompt = `Create a short, animated video summarizing the science experiment: "${experimentName}".
    - Aim: ${details.aim}.
    - Key Steps: ${procedureSummary}.
    - Conclusion: ${results.conclusion}.
    The style should be a clean, educational animation, visually representing the apparatus and the scientific process.`;

  try {
    let operation = await videoAi.models.generateVideos({
      model: 'veo-3.1-fast-generate-preview',
      prompt: prompt,
      config: {
        numberOfVideos: 1,
        resolution: '720p',
        aspectRatio: '16:9'
      }
    });

    while (!operation.done) {
      // Wait for 10 seconds before polling again
      await new Promise(resolve => setTimeout(resolve, 10000));
      operation = await videoAi.operations.getVideosOperation({ operation: operation });
    }

    const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
    if (!downloadLink) {
      throw new Error("Video generation completed, but no download link was found.");
    }

    return downloadLink;

  } catch (error) {
    console.error("Error generating video:", error);
    // Re-throw the error so the component can handle it (e.g., for API key issues)
    throw error;
  }
};