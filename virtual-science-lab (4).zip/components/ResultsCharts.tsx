import React, { useMemo } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface ResultsChartsProps {
  markdownContent: string;
}

// Data format for charts: an array of objects
type ChartData = Record<string, number | string>[];

const parseMarkdownTableToData = (markdown: string): { headers: string[]; data: ChartData } | null => {
    const lines = markdown.trim().split('\n').filter(line => line.includes('|'));
    if (lines.length < 3) return null; // Needs header, separator, and at least one data row

    const parseRow = (rowString: string): string[] => {
        const row = rowString.trim();
        const cleanedRow = row.startsWith('|') && row.endsWith('|') ? row.substring(1, row.length - 1) : row;
        return cleanedRow.split('|').map(cell => cell.trim());
    };

    try {
        const headers = parseRow(lines[0]).map(h => h.trim());
        const rows = lines.slice(2).map(parseRow);

        if (headers.length === 0 || rows.some(r => r.length !== headers.length)) {
             return null;
        }

        const data: ChartData = rows.map(row => {
            const rowObject: Record<string, string | number> = {};
            headers.forEach((header, index) => {
                const value = row[index];
                // Try to convert to number, but keep as string if it fails
                const numericValue = Number(value);
                rowObject[header] = isNaN(numericValue) || value.trim() === '' ? value : numericValue;
            });
            return rowObject;
        });

        return { headers, data };
    } catch (e) {
        console.error("Failed to parse markdown table for charts:", e);
        return null;
    }
};

const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
        return (
            <div className="bg-slate-900/80 p-3 border border-slate-600 rounded-lg shadow-lg backdrop-blur-sm">
                <p className="label text-sm text-slate-300 font-bold">{`${payload[0].payload.hasOwnProperty(label) ? label : ''} ${label}`}</p>
                {payload.map((pld: any) => (
                    <p key={pld.name} className="intro text-sm" style={{ color: pld.color }}>
                        {`${pld.name}: ${pld.value}`}
                    </p>
                ))}
            </div>
        );
    }
    return null;
};


const ResultsCharts: React.FC<ResultsChartsProps> = ({ markdownContent }) => {
    const chartConfig = useMemo(() => {
        const parsed = parseMarkdownTableToData(markdownContent);
        if (!parsed) return null;

        const { headers, data } = parsed;

        // Find a suitable x-axis key (e.g., time, volume, trial number)
        const xAxisCandidates = ['Time', 'Volume', 'Serial', 'No', 'Reading', 'Current'];
        let xAxisKey = headers.find(h => xAxisCandidates.some(cand => h.toLowerCase().includes(cand.toLowerCase())));
        if(!xAxisKey) xAxisKey = headers[0]; // Default to the first column if no candidate is found

        // Find all other numeric y-axis keys
        const yAxisKeys = headers.filter(h => h !== xAxisKey && typeof data[0]?.[h] === 'number');

        if (!xAxisKey || yAxisKeys.length === 0) {
            return null;
        }
        
        // Ensure all data for the axes is numeric before rendering
        const chartableData = data.filter(d => typeof d[xAxisKey as string] === 'number');
        if (chartableData.length === 0) return null;


        return { data: chartableData, xAxisKey, yAxisKeys };
    }, [markdownContent]);

    if (!chartConfig) {
        return null; // Don't render anything if data is not chartable
    }

    const { data, xAxisKey, yAxisKeys } = chartConfig;
    const colors = ['#22d3ee', '#f87171', '#a78bfa', '#facc15', '#4ade80'];

    return (
        <div className="mt-8">
            <h4 className="text-lg font-semibold text-slate-100 mb-4">Data Visualization</h4>
            <div className="w-full h-80 bg-slate-800/50 p-4 rounded-lg border border-slate-700">
                 <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                        data={data}
                        margin={{ top: 5, right: 20, left: -10, bottom: 5 }}
                    >
                        <CartesianGrid strokeDasharray="3 3" stroke="#475569" />
                        <XAxis dataKey={xAxisKey} stroke="#94a3b8" tick={{ fontSize: 12 }} />
                        <YAxis stroke="#94a3b8" tick={{ fontSize: 12 }} />
                        <Tooltip content={<CustomTooltip />} cursor={{ stroke: '#64748b', strokeWidth: 1, strokeDasharray: '3 3' }} />
                        <Legend wrapperStyle={{fontSize: "14px", paddingTop: "10px"}} />
                        {yAxisKeys.map((yKey, index) => (
                            <Line
                                key={yKey}
                                type="monotone"
                                dataKey={yKey}
                                stroke={colors[index % colors.length]}
                                strokeWidth={2}
                                dot={{ r: 3, fill: colors[index % colors.length] }}
                                activeDot={{ r: 6, stroke: '#ffffff' }}
                            />
                        ))}
                    </LineChart>
                </ResponsiveContainer>
            </div>
        </div>
    );
};

export default ResultsCharts;
