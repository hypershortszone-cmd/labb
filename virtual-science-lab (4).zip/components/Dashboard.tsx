
import React from 'react';
import { Subject } from '../types';
import { EXPERIMENTS_DATA } from '../constants';
import { BackIcon, LabIcon } from './icons';

interface DashboardProps {
  subject: Subject;
  onSelectExperiment: (experimentName: string) => void;
  onBack: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ subject, onSelectExperiment, onBack }) => {
  const subjectData = EXPERIMENTS_DATA[subject];

  return (
    <div>
        <button onClick={onBack} className="flex items-center gap-2 text-cyan-400 hover:text-cyan-300 mb-6 transition-colors">
            <BackIcon />
            <span>Change Subject</span>
        </button>
      <h2 className="text-3xl font-bold mb-2 text-white">
        {subject} Laboratory
      </h2>
      <p className="text-slate-400 mb-8">Select an experiment to begin your practical session.</p>

      <div className="space-y-8">
        {subjectData.map((chapter) => (
          <div key={chapter.chapter} className="bg-slate-800/50 p-6 rounded-lg border border-slate-700 shadow-xl">
            <h3 className="text-xl font-semibold text-cyan-400 mb-4">{chapter.chapter}</h3>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {chapter.experiments.map((experiment) => (
                <button
                  key={experiment}
                  onClick={() => onSelectExperiment(experiment)}
                  className="bg-slate-700 p-4 rounded-lg text-left hover:bg-slate-600/70 hover:shadow-cyan-500/10 shadow-lg transition-all duration-300 group"
                >
                  <div className="flex items-start gap-3">
                    <div className="mt-1 text-cyan-500">
                      <LabIcon />
                    </div>
                    <div>
                        <h4 className="font-semibold text-slate-200">{experiment}</h4>
                        <p className="text-sm text-slate-400 group-hover:text-cyan-400 mt-1 transition-colors">Proceed to experiment &rarr;</p>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Dashboard;
