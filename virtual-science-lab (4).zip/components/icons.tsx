import React from 'react';

type IconProps = {
    size?: 'sm' | 'md' | 'lg' | 'xl' | 'xxl';
    className?: string;
};

const sizeMap = {
    sm: 'h-4 w-4',
    md: 'h-6 w-6',
    lg: 'h-8 w-8',
    xl: 'h-10 w-10',
    xxl: 'h-24 w-24',
};

export const HeaderIcon: React.FC = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-cyan-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path>
    <polyline points="14 2 14 8 20 8"></polyline>
    <path d="M12 18v-6"></path>
    <path d="M9 15h6"></path>
  </svg>
);

export const CheckIcon: React.FC<IconProps> = ({ size = 'sm' }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={sizeMap[size]} viewBox="0 0 20 20" fill="currentColor">
    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
  </svg>
);

export const ChevronDownIcon: React.FC<IconProps> = ({ size = 'md' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={sizeMap[size]} viewBox="0 0 20 20" fill="currentColor">
      <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
    </svg>
);

export const BackIcon: React.FC<IconProps> = ({ size = 'md' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`${sizeMap[size]}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
    </svg>
);

export const LabIcon: React.FC<IconProps> = ({ size = 'md' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`${sizeMap[size]}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
    </svg>
);

export const InfoIcon: React.FC<IconProps> = ({ size = 'md', className = '' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`${sizeMap[size]} ${className}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);

export const ScienceIcon: React.FC<IconProps> = ({ size = 'md', className = '' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`${sizeMap[size]} ${className}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h8a2 2 0 002-2v-4a2 2 0 00-2-2h-8a2 2 0 00-2 2v4a2 2 0 002 2z"></path>
    </svg>
);

export const ResultsIcon: React.FC<IconProps> = ({ size = 'md', className = '' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`${sizeMap[size]} ${className}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V7a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
    </svg>
);

export const WarningIcon: React.FC<IconProps> = ({ size = 'md', className = '' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`${sizeMap[size]} ${className}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
    </svg>
);

export const BeakerIcon: React.FC<IconProps> = ({ size = 'md', className = '' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`${sizeMap[size]} ${className}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h8a2 2 0 002-2v-4a2 2 0 00-2-2h-8a2 2 0 00-2 2v4a2 2 0 002 2z" />
    </svg>
);

export const FlaskIcon: React.FC<IconProps> = ({ size = 'md', className = '' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`${sizeMap[size]} ${className}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 2v8l-4 8h14l-4-8V2H9z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M7 4h10" />
    </svg>
);

export const PipetteIcon: React.FC<IconProps> = ({ size = 'md', className = '' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`${sizeMap[size]} ${className}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v18m-2-2h4m-2-14a2 2 0 110-4 2 2 0 010 4z" />
    </svg>
);

export const BurnerIcon: React.FC<IconProps> = ({ size = 'md', className = '' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`${sizeMap[size]} ${className}`} viewBox="0 0 48 48" fill="none" stroke="currentColor" strokeWidth="3">
        <path strokeLinecap="round" strokeLinejoin="round" d="M8 44h32v-4H8v4z M14 40v-8h20v8 M18 32V20h12v12" />
    </svg>
);

export const TripodStandIcon: React.FC<IconProps> = ({ size = 'md', className = '' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`${sizeMap[size]} ${className}`} viewBox="0 0 48 48" fill="none" stroke="currentColor" strokeWidth="3">
        <path strokeLinecap="round" strokeLinejoin="round" d="M24 10 L 10 44 M 24 10 L 38 44 M 14 28 H 34" />
        <circle cx="24" cy="10" r="6" stroke="currentColor" strokeWidth="3" fill="none"/>
    </svg>
);

export const PhIcon: React.FC<IconProps> = ({ size = 'md', className = '' }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={`${sizeMap[size]} ${className}`} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M10 2h4" /><path d="M8 6h8" /><path d="M10 22h4" /><path d="M12 6v16" /><path d="M6 12H2" /><path d="M22 12h-4" />
  </svg>
);

export const TemperatureIcon: React.FC<IconProps> = ({ size = 'md', className = '' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`${sizeMap[size]} ${className}`} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M14 14.76V3.5a2.5 2.5 0 00-5 0v11.26a4 4 0 105 0z" />
    </svg>
);

export const ConcentrationIcon: React.FC<IconProps> = ({ size = 'md', className = '' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`${sizeMap[size]} ${className}`} viewBox="0 0 24 24" fill="currentColor">
        <circle cx="6" cy="6" r="1.5" /><circle cx="10" cy="6" r="1.5" /><circle cx="14" cy="6" r="1.5" /><circle cx="18" cy="6" r="1.5" /><circle cx="8" cy="12" r="1.5" /><circle cx="12" cy="12" r="1.5" /><circle cx="16" cy="12" r="1.5" /><circle cx="10" cy="18" r="1.5" /><circle cx="14" cy="18" r="1.5" />
    </svg>
);

export const EarthIcon: React.FC<IconProps> = ({ size = 'md', className = '' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`${sizeMap[size]} ${className}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);
export const MarsIcon: React.FC<IconProps> = ({ size = 'md', className = '' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`${sizeMap[size]} ${className}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 22a10 10 0 100-20 10 10 0 000 20z" />
       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
    </svg>
);
export const MoonIcon: React.FC<IconProps> = ({ size = 'md', className = '' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`${sizeMap[size]} ${className}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z" />
    </svg>
);
export const RocketIcon: React.FC<IconProps> = ({ size = 'md', className = '' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`${sizeMap[size]} ${className}`} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 2L2 22h20L12 2zM12 18v-4" />
    </svg>
);

export const PlusIcon: React.FC<IconProps> = ({ size = 'sm', className = '' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`${sizeMap[size]} ${className}`} viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" />
    </svg>
);

export const SpeedIcon: React.FC<IconProps> = ({ size = 'md', className = '' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`${sizeMap[size]} ${className}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
    </svg>
);

export const PressureIcon: React.FC<IconProps> = ({ size = 'md', className = '' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`${sizeMap[size]} ${className}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M20 12H4m16 0l-4 4m4-4l-4-4M4 12l4 4M4 12l4-4" />
    </svg>
);

export const SaveIcon: React.FC<IconProps> = ({ size = 'md', className = '' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`${sizeMap[size]} ${className}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4" />
    </svg>
);

export const LoadIcon: React.FC<IconProps> = ({ size = 'md', className = '' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`${sizeMap[size]} ${className}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1-4l-3 3m0 0l-3-3m3 3v10" />
    </svg>
);

export const RefreshIcon: React.FC<IconProps> = ({ size = 'md', className = '' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`${sizeMap[size]} ${className}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h5M20 20v-5h-5" />
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 9a9 9 0 0114.13-5.12M20 15a9 9 0 01-14.13 5.12" />
    </svg>
);

export const VideoIcon: React.FC<IconProps> = ({ size = 'md', className = '' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`${sizeMap[size]} ${className}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
    </svg>
);

export const KeyIcon: React.FC<IconProps> = ({ size = 'md', className = '' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`${sizeMap[size]} ${className}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 7a4 4 0 11-8 0 4 4 0 018 0zM12 15v5m-3-2h6" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 12a3 3 0 00-3 3v1h6v-1a3 3 0 00-3-3z" />
    </svg>
);

export const DownloadIcon: React.FC<IconProps> = ({ size = 'md', className = '' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`${sizeMap[size]} ${className}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
    </svg>
);

export const FlameIcon: React.FC<IconProps> = ({ size = 'md', className = '' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`${sizeMap[size]} ${className}`} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 2C8.686 2 6 4.686 6 8c0 4.97 6 12 6 12s6-7.03 6-12c0-3.314-2.686-6-6-6z" />
      <path d="M12 12a3 3 0 100-6 3 3 0 000 6z" />
    </svg>
);

// Note: These icons are not used in ExperimentView but could be useful for other components
export const WaterMoleculeIcon: React.FC<IconProps> = ({ size = 'md', className = '' }) => (<div className={className}>H₂O</div>);
export const HClMoleculeIcon: React.FC<IconProps> = ({ size = 'md', className = '' }) => (<div className={className}>HCl</div>);
export const NaOHMoleculeIcon: React.FC<IconProps> = ({ size = 'md', className = '' }) => (<div className={className}>NaOH</div>);
