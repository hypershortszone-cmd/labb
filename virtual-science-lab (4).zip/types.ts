export type Board = 'CBSE' | 'ICSE' | 'State Board';
export type ClassLevel = '9th' | '10th' | '11th' | '12th';
export type Subject = 'Physics' | 'Chemistry' | 'Biology';

export interface OnboardingData {
  board: Board;
  classLevel: ClassLevel;
  subject: Subject;
}

export interface ProcedureStep {
  step: string;
  key: 'SETUP_APPARATUS' | 'ADD_CHEMICAL' | 'HEAT' | 'MEASURE' | 'OBSERVE' | 'CLEAN' | string; // Allow for other keys
  explanation: string;
}

export interface ExperimentDetails {
  aim: string;
  theory: string;
  apparatus: string[];
  procedureSteps: ProcedureStep[];
  precautions: string[];
}

export interface ExperimentResult {
  observations: string;
  calculations: string;
  conclusion: string;
}